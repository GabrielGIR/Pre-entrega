from setuptools import setup

setup (
    name='generadorcontra',
    version='2.0v',
    description='Genera contraseñas aleatorias',
    author='Gabriel',
    packages=['modulos']
)